package com.example.ch5_event

import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.View.OnClickListener
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ch5_event.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var initTime = 0L//back button 이 눌린 시간
    var pauseTime = 0L//chronometer pause 시간..

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //OnClickListener 인터페이스를 구현한 익명 클래스..
        //kotlin - 익명 클래스 object 예약어로..
        binding.startButton.setOnClickListener(object: OnClickListener {
            override fun onClick(p0: View?) {
                binding.chronometer.base = SystemClock.elapsedRealtime() + pauseTime
                binding.chronometer.start()

                binding.startButton.isEnabled = false
                binding.stopButton.isEnabled = true
                binding.resetButton.isEnabled = true
            }
        })
        //Single Abstract Method 기법
        //추상함수 하나를 가지는 인터페이스를 구현한 클래스를 선언할때. 윗처럼 작성해도 되지만..
        //오버라이드 받는 추상함수 안의 내용만 {} 에 줄여서 작성..
        binding.stopButton.setOnClickListener({
            pauseTime = binding.chronometer.base - SystemClock.elapsedRealtime()
            binding.chronometer.stop()

            binding.startButton.isEnabled = true
            binding.stopButton.isEnabled = false
            binding.resetButton.isEnabled = true
        })
    }
}